/* ========================================
   VYRA - Articles Data
   ======================================== */

const articles = [

    {
        id: 1,

        title:
            "Artificial Intelligence ဆိုတာဘာလဲ?",

        slug:
            "what-is-artificial-intelligence",

        categoryId:
            1,

        excerpt:
            "Artificial Intelligence (AI) ဆိုတာ လူသားတွေရဲ့ ဉာဏ်ရည်အသုံးပြုမှုနဲ့ ဆင်တူတဲ့ အလုပ်တွေကို ကွန်ပျူတာစနစ်တွေက လုပ်ဆောင်နိုင်စေတဲ့ နည်းပညာတစ်ခုဖြစ်ပါတယ်။",

        content: [

            {
                type: "paragraph",

                text:
                    "Artificial Intelligence ကို အတိုကောက် AI လို့ ခေါ်ပါတယ်။ AI ဆိုတာ ကွန်ပျူတာနဲ့ စက်ပစ္စည်းတွေကို လူသားတွေရဲ့ ဉာဏ်ရည်အသုံးပြုမှုနဲ့ ဆင်တူတဲ့ အလုပ်တွေကို လုပ်ဆောင်နိုင်အောင် ဖန်တီးထားတဲ့ နည်းပညာတစ်ခု ဖြစ်ပါတယ်။"
            },


            {
                type: "heading",

                level: 2,

                text:
                    "AI ဘယ်လိုအလုပ်လုပ်သလဲ?"
            },


            {
                type: "paragraph",

                text:
                    "AI စနစ်တွေဟာ အချက်အလက်တွေကို လေ့လာပြီး ပုံစံတွေကို ရှာဖွေနိုင်ပါတယ်။ အဲဒီအချက်အလက်တွေကို အသုံးပြုပြီး မေးခွန်းတွေကို ဖြေဆိုတာ၊ စာရေးတာ၊ ပုံတွေကို နားလည်တာနဲ့ အခြားလုပ်ဆောင်ချက်တွေကို လုပ်နိုင်ပါတယ်။"
            },


            {
                type: "image",

                url:
                    "assets/images/articles/ai-example.jpg",

                caption:
                    "Artificial Intelligence စနစ်တစ်ခု၏ ဥပမာ။"
            },


            {
                type: "quote",

                text:
                    "နည်းပညာဟာ ကျွန်ုပ်တို့ ကမ္ဘာကြီးကို နားလည်ပုံနဲ့ အသုံးပြုပုံကို ပြောင်းလဲနိုင်ပါတယ်။"
            },


            {
                type: "list",

                style:
                    "unordered",

                items: [
                    "Machine Learning",
                    "Computer Vision",
                    "Natural Language Processing"
                ]
            }

        ],

        image:
            "assets/images/articles/ai.jpg",

        authorId:
            1,

        readingTime:
            3,

        tags: [
            "AI",
            "Artificial Intelligence",
            "နည်းပညာ"
        ],

        status:
            "published",

        featured:
            true,

        publishedAt:
            "2026-09-16T10:00:00Z",

        createdAt:
            "2026-09-16T09:00:00Z",

        updatedAt:
            "2026-09-16T09:00:00Z"
    },


    {
        id: 2,

        title:
            "Web Development ကို ဘယ်လိုစလေ့လာမလဲ?",

        slug:
            "how-to-learn-web-development",

        categoryId:
            2,

        excerpt:
            "Web Development ကို စတင်လေ့လာချင်သူတွေအတွက် HTML, CSS နဲ့ JavaScript ကနေ စတင်လေ့လာနိုင်တဲ့ ရိုးရှင်းတဲ့လမ်းကြောင်း။",

        content: [

            {
                type: "paragraph",

                text:
                    "Web Development ကို စတင်လေ့လာမယ်ဆိုရင် HTML, CSS နဲ့ JavaScript ဆိုတဲ့ အခြေခံနည်းပညာသုံးခုကို အရင်နားလည်ထားသင့်ပါတယ်။"
            },


            {
                type: "heading",

                level: 2,

                text:
                    "အခြေခံကနေ စတင်ပါ"
            },


            {
                type: "paragraph",

                text:
                    "အခြေခံတွေကို သေချာနားလည်ထားရင် နောက်ပိုင်းမှာ Framework တွေနဲ့ ပိုမိုအဆင့်မြင့်တဲ့ Web Technology တွေကို လေ့လာရတာ ပိုလွယ်ကူလာပါလိမ့်မယ်။"
            }

        ],

        image:
            "assets/images/articles/web-development.jpg",

        authorId:
            1,

        readingTime:
            4,

        tags: [
            "Web Development",
            "HTML",
            "CSS",
            "JavaScript"
        ],

        status:
            "published",

        featured:
            false,

        publishedAt:
            "2026-09-15T10:00:00Z",

        createdAt:
            "2026-09-15T09:00:00Z",

        updatedAt:
            "2026-09-15T09:00:00Z"
    }

];