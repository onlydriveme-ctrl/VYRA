/* ========================================
   VYRA - Categories Data
   ======================================== */

const categories = [

    {
        id: 1,
        name: "AI",
        slug: "ai"
    },

    {
        id: 2,
        name: "Technology",
        slug: "technology"
    },

    {
        id: 3,
        name: "Movies",
        slug: "movies"
    },

    {
        id: 4,
        name: "Anime",
        slug: "anime"
    },

    {
        id: 5,
        name: "Knowledge",
        slug: "knowledge"
    },

    {
        id: 6,
        name: "Digital Life",
        slug: "digital-life"
    }

];