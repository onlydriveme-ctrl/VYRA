/* ========================================
   VYRA - Article Cards
   ======================================== */

(function () {


    const featuredArea =
        document.querySelector(
            "[data-featured-article]"
        );


    const latestArea =
        document.querySelector(
            "[data-latest-articles]"
        );

    if (
        typeof articles === "undefined" ||
        !Array.isArray(articles) ||
        typeof categories === "undefined" ||
        !Array.isArray(categories)
    ) {
        return;
    }


    /* ========================================
       Category
       ======================================== */

    function getCategoryName(categoryId) {

        const category =
            categories.find(function (item) {

                return item.id === categoryId;

            });


        return category
            ? category.name
            : "Uncategorized";

    }



    /* ========================================
       Date
       ======================================== */

    function getArticleDate(date) {

        return new Date(
            date
        ).toLocaleDateString(
            "en-US",
            {
                year: "numeric",
                month: "short",
                day: "numeric"
            }
        );

    }



    /* ========================================
       Create Card
       ======================================== */

    function createCard(article) {

        const card =
            document.createElement("a");


        card.className =
            "content-card";


        card.href =
            "pages/article.html?slug=" +
            encodeURIComponent(
                article.slug
            );



        /* Category */

        const category =
            document.createElement("div");


        category.className =
            "card-category";


        category.textContent =
            getCategoryName(
                article.categoryId
            );



        /* Title */

        const title =
            document.createElement("h3");


        title.textContent =
            article.title;



        /* Excerpt */

        const excerpt =
            document.createElement("p");


        excerpt.className =
            "card-excerpt";


        excerpt.textContent =
            article.excerpt;



        /* Meta */

        const meta =
            document.createElement("div");


        meta.className =
            "card-meta";


        const readingTime =
            article.readingTime
                ? article.readingTime +
                  " min read"
                : "";


        const publishedDate =
            article.publishedAt
                ? getArticleDate(
                    article.publishedAt
                )
                : "";


        if (
            readingTime &&
            publishedDate
        ) {

            meta.textContent =
                readingTime +
                " · " +
                publishedDate;

        }

        else if (readingTime) {

            meta.textContent =
                readingTime;

        }

        else if (publishedDate) {

            meta.textContent =
                publishedDate;

        }



        /* Tags */

        if (
            Array.isArray(article.tags) &&
            article.tags.length
        ) {

            const tags =
                document.createElement(
                    "div"
                );


            tags.className =
                "card-tags";


            article.tags.forEach(
                function (tag) {

                    const tagElement =
                        document.createElement(
                            "span"
                        );


                    tagElement.className =
                        "card-tag";


                    tagElement.textContent =
                        tag;


                    tags.append(
                        tagElement
                    );

                }
            );


            card.append(
                category,
                title,
                excerpt,
                meta,
                tags
            );

        }

        else {

            card.append(
                category,
                title,
                excerpt,
                meta
            );

        }


        return card;

    }



    /* ========================================
       Published Articles
       ======================================== */

    const publishedArticles =
        articles.filter(function (article) {

            return (
                article.status ===
                "published"
            );

        });



    /* ========================================
       Featured
       ======================================== */

    let featuredArticle = null;


    if (featuredArea) {

        featuredArticle =
            publishedArticles.find(
                function (article) {

                    return (
                        article.featured ===
                        true
                    );

                }
            );


        if (featuredArticle) {

            featuredArea.append(
                createCard(
                    featuredArticle
                )
            );

        }

    }



    /* ========================================
       Latest
       ======================================== */

    if (latestArea) {

        const latest =
            [...publishedArticles]
                .filter(function (article) {

                    return (
                        !featuredArticle ||
                        article.id !==
                        featuredArticle.id
                    );

                })
                .sort(function (a, b) {

                    return (
                        new Date(
                            b.publishedAt
                        ) -
                        new Date(
                            a.publishedAt
                        )
                    );

                });


        latest.forEach(
            function (article) {

                latestArea.append(
                    createCard(article)
                );

            }
        );

    }


})();