/* ========================================
   VYRA - Article
   ======================================== */

(function () {


    const articleCover =
        document.querySelector(
            ".article-cover"
        );


    const articleCoverImage =
        document.querySelector(
            ".article-cover-image"
        );


    const articleCategory =
        document.querySelector(
            ".article-category"
        );


    const articleTitle =
        document.querySelector(
            ".article-title"
        );


    const articleExcerpt =
        document.querySelector(
            ".article-excerpt"
        );


    const articleMeta =
        document.querySelector(
            ".article-meta"
        );


    const articleTags =
        document.querySelector(
            ".article-tags"
        );


    const articleContent =
        document.querySelector(
            ".article-content"
        );


    const relatedArticles =
        document.querySelector(
            "[data-related-articles]"
        );

    if (
        typeof articles === "undefined" ||
        !Array.isArray(articles) ||
        typeof categories === "undefined" ||
        !Array.isArray(categories)
    ) {
        if (articleTitle) {
            articleTitle.textContent = "Article data မတွေ့ပါ။";
        }
        return;
    }


    /* ========================================
       Get Article
       ======================================== */

    const params =
        new URLSearchParams(
            window.location.search
        );


    const slug =
        params.get("slug");


    const article =
        articles.find(function (item) {

            return (
                item.slug === slug &&
                item.status === "published"
            );

        });



    /* ========================================
       Category
       ======================================== */

    function getCategoryName(categoryId) {

        const category =
            categories.find(function (item) {

                return item.id === categoryId;

            });


        return category
            ? category.name
            : "Uncategorized";

    }



    /* ========================================
       Author
       ======================================== */

    function getAuthorName(authorId) {

        if (typeof users === "undefined" || !Array.isArray(users)) {
            return "VYRA";
        }

        const author =
            users.find(function (item) {

                return item.id === authorId;

            });


        return author
            ? author.name
            : "VYRA";

    }



    /* ========================================
       Date
       ======================================== */

    function getArticleDate(date) {

        return new Date(
            date
        ).toLocaleDateString(
            "en-US",
            {
                year: "numeric",
                month: "long",
                day: "numeric"
            }
        );

    }



    /* ========================================
       Related Articles
       ======================================== */

    function getRelatedArticles(currentArticle) {

        return articles
            .filter(function (item) {

                if (
                    item.id ===
                    currentArticle.id
                ) {
                    return false;
                }


                if (
                    item.status !==
                    "published"
                ) {
                    return false;
                }


                const sameCategory =
                    item.categoryId ===
                    currentArticle.categoryId;


                const currentTags =
                    Array.isArray(
                        currentArticle.tags
                    )
                        ? currentArticle.tags
                        : [];


                const itemTags =
                    Array.isArray(
                        item.tags
                    )
                        ? item.tags
                        : [];


                const sharedTags =
                    itemTags.filter(
                        function (tag) {

                            return currentTags.includes(
                                tag
                            );

                        }
                    ).length;


                return (
                    sameCategory ||
                    sharedTags > 0
                );

            })
            .sort(function (a, b) {

                const aSameCategory =
                    a.categoryId ===
                    currentArticle.categoryId
                        ? 1
                        : 0;


                const bSameCategory =
                    b.categoryId ===
                    currentArticle.categoryId
                        ? 1
                        : 0;


                if (
                    aSameCategory !==
                    bSameCategory
                ) {

                    return (
                        bSameCategory -
                        aSameCategory
                    );

                }


                return (
                    new Date(
                        b.publishedAt
                    ) -
                    new Date(
                        a.publishedAt
                    )
                );

            })
            .slice(0, 3);

    }



    /* ========================================
       Render Tags
       ======================================== */

    function renderTags(tags) {

        if (
            !articleTags ||
            !Array.isArray(tags) ||
            !tags.length
        ) {
            return;
        }


        tags.forEach(function (tag) {

            const tagElement =
                document.createElement(
                    "span"
                );


            tagElement.className =
                "article-tag";


            tagElement.textContent =
                tag;


            articleTags.append(
                tagElement
            );

        });

    }



    /* ========================================
       Render Related Articles
       ======================================== */

    function renderRelatedArticles(
        currentArticle
    ) {

        if (!relatedArticles) {
            return;
        }


        const related =
            getRelatedArticles(
                currentArticle
            );


        if (!related.length) {

            const section =
                relatedArticles.closest(
                    ".related-articles"
                );


            if (section) {
                section.remove();
            }


            return;

        }


        related.forEach(
            function (item) {

                const card =
                    document.createElement(
                        "a"
                    );


                card.className =
                    "content-card";


                card.href =
                    "article.html?slug=" +
                    encodeURIComponent(
                        item.slug
                    );


                const category =
                    document.createElement(
                        "div"
                    );


                category.className =
                    "card-category";


                category.textContent =
                    getCategoryName(
                        item.categoryId
                    );


                const title =
                    document.createElement(
                        "h3"
                    );


                title.textContent =
                    item.title;


                const excerpt =
                    document.createElement(
                        "p"
                    );


                excerpt.className =
                    "card-excerpt";


                excerpt.textContent =
                    item.excerpt;


                const meta =
                    document.createElement(
                        "div"
                    );


                meta.className =
                    "card-meta";


                if (item.readingTime) {

                    meta.textContent =
                        item.readingTime +
                        " min read";

                }


                card.append(
                    category,
                    title,
                    excerpt,
                    meta
                );


                relatedArticles.append(
                    card
                );

            }
        );

    }



    /* ========================================
       Render Content Block
       ======================================== */

    function renderBlock(block) {

        let element = null;


        if (block.type === "paragraph") {

            element =
                document.createElement("p");

            element.textContent =
                block.text;

        }


        else if (block.type === "heading") {

            const level =
                Number(block.level);


            if (
                level >= 2 &&
                level <= 6
            ) {

                element =
                    document.createElement(
                        "h" + level
                    );


                element.textContent =
                    block.text;

            }

        }


        else if (block.type === "image") {

            const figure =
                document.createElement(
                    "figure"
                );


            const image =
                document.createElement(
                    "img"
                );


            image.src =
                "../" + block.url;


            image.alt =
                block.caption || "";


            image.loading =
                "lazy";


            figure.append(
                image
            );


            if (block.caption) {

                const caption =
                    document.createElement(
                        "figcaption"
                    );


                caption.textContent =
                    block.caption;


                figure.append(
                    caption
                );

            }


            element =
                figure;

        }


        else if (block.type === "quote") {

            element =
                document.createElement(
                    "blockquote"
                );


            element.textContent =
                block.text;

        }


        else if (block.type === "list") {

            element =
                document.createElement(
                    block.style === "ordered"
                        ? "ol"
                        : "ul"
                );


            if (Array.isArray(block.items)) {

                block.items.forEach(
                    function (item) {

                        const listItem =
                            document.createElement(
                                "li"
                            );


                        listItem.textContent =
                            item;


                        element.append(
                            listItem
                        );

                    }
                );

            }

        }


        else if (block.type === "video") {

            const videoArea =
                document.createElement(
                    "div"
                );


            videoArea.className =
                "article-video";


            const link =
                document.createElement(
                    "a"
                );


            link.href =
                block.url;


            link.target =
                "_blank";


            link.rel =
                "noopener noreferrer";


            link.textContent =
                "Watch video";


            videoArea.append(
                link
            );


            element =
                videoArea;

        }


        return element;

    }



    /* ========================================
       Render Article
       ======================================== */

    if (
        article &&
        articleCover &&
        articleCoverImage &&
        articleCategory &&
        articleTitle &&
        articleExcerpt &&
        articleMeta &&
        articleTags &&
        articleContent
    ) {


        /* Cover Image */

        if (article.image) {

            articleCoverImage.src =
                "../" + article.image;


            articleCoverImage.alt =
                article.title;


        } else {

            articleCover.remove();

        }



        /* Category */

        articleCategory.textContent =
            getCategoryName(
                article.categoryId
            );



        /* Title */

        articleTitle.textContent =
            article.title;



        /* Excerpt */

        articleExcerpt.textContent =
            article.excerpt;



        /* Meta */

        const author =
            getAuthorName(
                article.authorId
            );


        const readingTime =
            article.readingTime
                ? article.readingTime +
                  " min read"
                : "";


        const publishedDate =
            article.publishedAt
                ? getArticleDate(
                    article.publishedAt
                )
                : "";


        const metaParts = [
            author,
            readingTime,
            publishedDate
        ].filter(Boolean);


        articleMeta.textContent =
            metaParts.join(" · ");



        /* Tags */

        renderTags(
            article.tags
        );



        /* Content */

        if (
            Array.isArray(
                article.content
            )
        ) {

            article.content.forEach(
                function (block) {

                    const element =
                        renderBlock(
                            block
                        );


                    if (element) {

                        articleContent.append(
                            element
                        );

                    }

                }
            );

        }



        /* Related Articles */

        renderRelatedArticles(
            article
        );



        /* Page Title */

        document.title =
            article.title +
            " - VYRA";

        const metaDescription =
            document.querySelector(
                'meta[name="description"]'
            );

        if (metaDescription) {
            metaDescription.setAttribute(
                "content",
                article.excerpt || "VYRA article"
            );
        }
    }


    else if (articleTitle) {


        articleTitle.textContent =
            "Article not found.";


        document.title =
            "Article Not Found - VYRA";


        if (articleExcerpt) {

            articleExcerpt.textContent =
                "The article you are looking for does not exist or is no longer available.";

        }


        if (articleCover) {

            articleCover.remove();

        }


        if (articleMeta) {

            articleMeta.textContent = "";

        }


        if (articleTags) {

            articleTags.textContent = "";

        }


        if (articleContent) {

            articleContent.innerHTML = "";

        }


        if (relatedArticles) {

            const section =
                relatedArticles.closest(
                    ".related-articles"
                );


            if (section) {
                section.remove();
            }

        }

    }


})();