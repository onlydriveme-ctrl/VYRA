/* ========================================
   VYRA - Search Results
   ======================================== */

(function () {

    const resultsArea =
        document.querySelector(
            ".search-results"
        );

    const keywordElement =
        document.querySelector(
            ".search-keyword"
        );

    const resultText =
        document.querySelector(
            ".search-result-text"
        );

    if (
        !resultsArea ||
        !keywordElement
    ) {
        return;
    }

    if (
        typeof articles === "undefined" ||
        !Array.isArray(articles) ||
        typeof categories === "undefined" ||
        !Array.isArray(categories)
    ) {
        resultsArea.textContent = "Search data မတွေ့ပါ။";
        return;
    }


    /* ----------------------------------------
       Get search keyword
    ---------------------------------------- */

    const params =
        new URLSearchParams(
            window.location.search
        );

    const keyword =
        (params.get("q") || "").trim();

    keywordElement.textContent =
        keyword;


    /* ----------------------------------------
       Empty keyword
    ---------------------------------------- */

    if (!keyword) {

        resultsArea.innerHTML =
            '<div class="search-results-message">' +
            'Search လုပ်ရန် keyword တစ်ခုထည့်ပါ။' +
            '</div>';

        if (resultText) {
            resultText.textContent =
                "ရှာဖွေလိုတဲ့ အကြောင်းအရာကို ရိုက်ထည့်ပါ။";
        }

        return;

    }


    /* ----------------------------------------
       Search term
    ---------------------------------------- */

    const searchTerm =
        keyword.toLowerCase();


    /* ----------------------------------------
       Search articles
    ---------------------------------------- */

    const results =
        articles.filter(
            function (article) {

                if (
                    article.status !==
                    "published"
                ) {
                    return false;
                }


                /* Title */

                const title =
                    (
                        article.title || ""
                    ).toLowerCase();


                /* Excerpt */

                const excerpt =
                    (
                        article.excerpt || ""
                    ).toLowerCase();


                /* Category */

                const category =
                    categories.find(
                        function (item) {

                            return (
                                item.id ===
                                article.categoryId
                            );

                        }
                    );

                const categoryName =
                    category
                        ? category.name.toLowerCase()
                        : "";


                /* Content */

                let contentText = "";

                if (
                    Array.isArray(
                        article.content
                    )
                ) {

                    contentText =
                        article.content
                            .map(
                                function (block) {

                                    return (
                                        block.text ||
                                        block.caption ||
                                        ""
                                    );

                                }
                            )
                            .join(" ")
                            .toLowerCase();

                }


                /* Tags */

                let tagText = "";

                if (
                    Array.isArray(
                        article.tags
                    )
                ) {

                    tagText =
                        article.tags
                            .join(" ")
                            .toLowerCase();

                }


                return (
                    title.includes(searchTerm) ||
                    excerpt.includes(searchTerm) ||
                    categoryName.includes(searchTerm) ||
                    contentText.includes(searchTerm) ||
                    tagText.includes(searchTerm)
                );

            }
        );


    /* ----------------------------------------
       Result count
    ---------------------------------------- */

    if (resultText) {

        resultText.textContent =
            results.length +
            (
                results.length === 1
                    ? " result found"
                    : " results found"
            ) +
            " for ";

        resultText.append(
            keywordElement
        );

    }


    /* ----------------------------------------
       No results
    ---------------------------------------- */

    if (!results.length) {

        resultsArea.innerHTML =
            '<div class="search-results-message">' +
            'သက်ဆိုင်တဲ့ article မတွေ့ပါ။' +
            '</div>';

        return;

    }


    /* ----------------------------------------
       Create result card
    ---------------------------------------- */

    results.forEach(
        function (article) {

            const card =
                document.createElement("a");

            card.className =
                "content-card";

            card.href =
                "article.html?slug=" +
                encodeURIComponent(
                    article.slug
                );


            /* Category */

            const categoryElement =
                document.createElement("div");

            categoryElement.className =
                "card-category";

            const category =
                categories.find(
                    function (item) {

                        return (
                            item.id ===
                            article.categoryId
                        );

                    }
                );

            categoryElement.textContent =
                category
                    ? category.name
                    : "Uncategorized";


            /* Title */

            const title =
                document.createElement("h3");

            title.textContent =
                article.title;


            /* Excerpt */

            const excerpt =
                document.createElement("p");

            excerpt.className =
                "card-excerpt";

            excerpt.textContent =
                article.excerpt;


            /* Meta */

            const meta =
                document.createElement("div");

            meta.className =
                "card-meta";

            if (article.readingTime) {

                meta.textContent =
                    article.readingTime +
                    " min read";

            }


            /* Tags */

            let tags = null;

            if (
                Array.isArray(article.tags) &&
                article.tags.length
            ) {

                tags =
                    document.createElement(
                        "div"
                    );

                tags.className =
                    "card-tags";


                article.tags.forEach(
                    function (tag) {

                        const tagElement =
                            document.createElement(
                                "span"
                            );

                        tagElement.className =
                            "card-tag";

                        tagElement.textContent =
                            tag;

                        tags.append(
                            tagElement
                        );

                    }
                );

            }


            /* Add card */

            card.append(
                categoryElement,
                title,
                excerpt,
                meta
            );

            if (tags) {
                card.append(tags);
            }

            resultsArea.append(card);

        }
    );

})();