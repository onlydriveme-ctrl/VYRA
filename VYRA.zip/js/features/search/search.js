/* ========================================
   VYRA - Search
   ======================================== */

(function () {

    const searchToggle =
        document.querySelector(".search-toggle");

    const searchIcon =
        document.querySelector(".search-icon");

    const searchPanel =
        document.querySelector(".search-panel");

    const searchForm =
        document.querySelector(".search-form");

    const searchInput =
        document.querySelector(".search-input");


    function closeSearch() {

        if (!searchPanel) return;

        searchPanel.classList.remove("is-open");

        if (searchIcon) {
            searchIcon.textContent = "⌕";
        }

        if (searchToggle) {

            searchToggle.setAttribute(
                "aria-label",
                "Open search"
            );

            searchToggle.setAttribute(
                "aria-expanded",
                "false"
            );

        }

    }


    if (searchToggle && searchPanel) {

        searchToggle.addEventListener(
            "click",
            function (event) {

                event.stopPropagation();


                const isOpen =
                    searchPanel.classList.contains(
                        "is-open"
                    );


                if (isOpen) {

                    closeSearch();

                } else {

                    /* Close Menu */

                    const navigation =
                        document.querySelector(
                            ".main-navigation"
                        );

                    const menuIcon =
                        document.querySelector(
                            ".menu-icon"
                        );

                    const menuToggle =
                        document.querySelector(
                            ".menu-toggle"
                        );


                    if (navigation) {

                        navigation.classList.remove(
                            "is-open"
                        );

                    }


                    if (menuIcon) {

                        menuIcon.textContent = "☰";

                    }


                    if (menuToggle) {

                        menuToggle.setAttribute(
                            "aria-label",
                            "Open menu"
                        );

                        menuToggle.setAttribute(
                            "aria-expanded",
                            "false"
                        );

                    }


                    searchPanel.classList.add(
                        "is-open"
                    );


                    if (searchIcon) {

                        searchIcon.textContent = "✕";

                    }


                    searchToggle.setAttribute(
                        "aria-label",
                        "Close search"
                    );

                    searchToggle.setAttribute(
                        "aria-expanded",
                        "true"
                    );


                    if (searchInput) {

                        searchInput.focus();

                    }

                }

            }
        );

    }


    if (searchForm && searchInput) {

        searchForm.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();


                const keyword =
                    searchInput.value.trim();


                if (!keyword) {

                    let message =
                        searchPanel.querySelector(
                            ".search-error-message"
                        );


                    if (!message) {

                        message =
                            document.createElement(
                                "p"
                            );

                        message.className =
                            "search-error-message";

                        searchPanel.appendChild(
                            message
                        );

                    }


                    message.textContent =
                        "Search လုပ်ရန် keyword တစ်ခုထည့်ပါ။";


                    searchInput.focus();

                    return;

                }


                const existingMessage =
                    searchPanel.querySelector(
                        ".search-error-message"
                    );


                if (existingMessage) {

                    existingMessage.remove();

                }


                const searchPage =
                    window.location.pathname.includes(
                        "/pages/"
                    )
                        ? "search.html"
                        : "pages/search.html";


                window.location.href =
                    searchPage +
                    "?q=" +
                    encodeURIComponent(keyword);

            }
        );

    }


    document.addEventListener(
        "click",
        function (event) {

            if (
                searchPanel &&
                searchToggle &&
                !searchPanel.contains(event.target) &&
                !searchToggle.contains(event.target)
            ) {

                closeSearch();

            }

        }
    );

})();