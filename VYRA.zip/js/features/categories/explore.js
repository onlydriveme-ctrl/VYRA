/* ========================================
   VYRA - Explore Categories
   ======================================== */

(function () {

    const exploreCategories =
        document.querySelector(
            "[data-explore-categories]"
        );

    if (!exploreCategories) {
        return;
    }


    /* ----------------------------------------
       Get article count
    ---------------------------------------- */

    function getArticleCount(categoryId) {

        if (
            typeof articles === "undefined" ||
            !Array.isArray(articles)
        ) {
            return 0;
        }

        return articles.filter(
            function (article) {

                return (
                    article.categoryId === categoryId &&
                    article.status === "published"
                );

            }
        ).length;

    }


    /* ----------------------------------------
       Category descriptions
    ---------------------------------------- */

    function getCategoryDescription(
        category
    ) {

        const descriptions = {

            "ai":
                "Artificial Intelligence နဲ့ AI နည်းပညာများ",

            "technology":
                "နည်းပညာ၊ Web Development နဲ့ Digital Tools များ",

            "movies":
                "ရုပ်ရှင်မိတ်ဆက်၊ Review နဲ့ ရုပ်ရှင်အကြောင်းအရာများ",

            "anime":
                "Anime မိတ်ဆက်၊ Recommendation နဲ့ အကြောင်းအရာများ",

            "knowledge":
                "ဗဟုသုတနဲ့ အသုံးဝင်တဲ့ အချက်အလက်များ",

            "digital-life":
                "အင်တာနက်၊ App တွေနဲ့ Digital Life အကြောင်းအရာများ"

        };

        return (
            descriptions[category.slug] ||
            "VYRA ရဲ့ အကြောင်းအရာများ"
        );

    }


    /* ----------------------------------------
       Check categories
    ---------------------------------------- */

    if (
        typeof categories === "undefined" ||
        !Array.isArray(categories)
    ) {

        exploreCategories.textContent =
            "Categories မတွေ့ပါ။";

        return;

    }


    /* ----------------------------------------
       Render categories
    ---------------------------------------- */

    categories.forEach(
        function (category) {

            const link =
                document.createElement("a");

            link.className =
                "explore-category";

            link.href =
                "category.html?slug=" +
                encodeURIComponent(
                    category.slug
                );


            const name =
                document.createElement("h2");

            name.className =
                "explore-category-name";

            name.textContent =
                category.name;


            const description =
                document.createElement("p");

            description.className =
                "explore-category-description";

            description.textContent =
                getCategoryDescription(
                    category
                );


            const count =
                document.createElement("div");

            count.className =
                "explore-category-count";

            const articleCount =
                getArticleCount(
                    category.id
                );

            count.textContent =
                articleCount +
                (
                    articleCount === 1
                        ? " article"
                        : " articles"
                );


            link.append(
                name,
                description,
                count
            );


            exploreCategories.append(
                link
            );

        }
    );

})();