/* ========================================
   VYRA - Category List
   ======================================== */

(function () {


    const categoryList =
        document.querySelector(
            "[data-categories]"
        );


    if (!categoryList) {
        return;
    }

    if (typeof categories === "undefined" || !Array.isArray(categories)) {
        return;
    }


    /* ========================================
       Render Categories
       ======================================== */

    categories.forEach(function (category) {


        const link =
            document.createElement("a");


        link.href =
            "pages/category.html?slug=" +
            encodeURIComponent(
                category.slug
            );


        link.textContent =
            category.name;


        categoryList.append(link);

    });


})();