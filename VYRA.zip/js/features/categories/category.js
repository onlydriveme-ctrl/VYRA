/* ========================================
   VYRA - Category
   ======================================== */

(function () {


    const categoryTitle =
        document.querySelector(
            ".category-title"
        );


    const categoryDescription =
        document.querySelector(
            ".category-description"
        );


    const categoryArticles =
        document.querySelector(
            "[data-category-articles]"
        );

    if (
        typeof categories === "undefined" ||
        !Array.isArray(categories) ||
        typeof articles === "undefined" ||
        !Array.isArray(articles)
    ) {
        if (categoryArticles) {
            categoryArticles.textContent = "Category data မတွေ့ပါ။";
        }
        return;
    }


    /* ========================================
       Get Category
       ======================================== */

    const params =
        new URLSearchParams(
            window.location.search
        );


    const slug =
        params.get("slug");


    const category =
        categories.find(function (item) {

            return item.slug === slug;

        });



    /* ========================================
       Category Name
       ======================================== */

    function getCategoryName(categoryId) {

        const category =
            categories.find(function (item) {

                return item.id === categoryId;

            });


        return category
            ? category.name
            : "Uncategorized";

    }



    /* ========================================
       Create Card
       ======================================== */

    function createCard(article) {

        const card =
            document.createElement("a");


        card.className =
            "content-card";


        card.href =
            "article.html?slug=" +
            encodeURIComponent(
                article.slug
            );



        /* Category */

        const categoryElement =
            document.createElement("div");


        categoryElement.className =
            "card-category";


        categoryElement.textContent =
            getCategoryName(
                article.categoryId
            );



        /* Title */

        const title =
            document.createElement("h3");


        title.textContent =
            article.title;



        /* Excerpt */

        const excerpt =
            document.createElement("p");


        excerpt.className =
            "card-excerpt";


        excerpt.textContent =
            article.excerpt;



        /* Meta */

        const meta =
            document.createElement("div");


        meta.className =
            "card-meta";


        meta.textContent =
            new Date(
                article.publishedAt
            ).toLocaleDateString();



        card.append(
            categoryElement,
            title,
            excerpt,
            meta
        );


        return card;

    }



    /* ========================================
       Render Category
       ======================================== */

    if (
        category &&
        categoryTitle &&
        categoryDescription &&
        categoryArticles
    ) {


        categoryTitle.textContent =
            category.name;


        categoryDescription.textContent =
            "Explore " +
            category.name +
            " articles on VYRA.";



        const filteredArticles =
            articles
                .filter(function (article) {

                    return (
                        article.categoryId ===
                        category.id &&
                        article.status ===
                        "published"
                    );

                })
                .sort(function (a, b) {

                    return (
                        new Date(
                            b.publishedAt
                        ) -
                        new Date(
                            a.publishedAt
                        )
                    );

                });



        filteredArticles.forEach(
            function (article) {

                categoryArticles.append(
                    createCard(article)
                );

            }
        );



        /* No Articles */

        if (!filteredArticles.length) {

            categoryArticles.textContent =
                "No articles found.";

        }



        document.title =
            category.name +
            " - VYRA";

    }



    /* ========================================
       Invalid Category
       ======================================== */

    else if (categoryArticles) {

        categoryArticles.textContent =
            "Category not found.";

    }


})();