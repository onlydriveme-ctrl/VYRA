/* ========================================
   VYRA - Mobile Menu
   ======================================== */

(function () {

    const menuToggle =
        document.querySelector(".menu-toggle");

    const menuIcon =
        document.querySelector(".menu-icon");

    const navigation =
        document.querySelector(".main-navigation");


    function closeMenu() {

        if (!navigation) return;

        navigation.classList.remove("is-open");

        if (menuIcon) {
            menuIcon.textContent = "☰";
        }

        if (menuToggle) {

            menuToggle.setAttribute(
                "aria-label",
                "Open menu"
            );

            menuToggle.setAttribute(
                "aria-expanded",
                "false"
            );

        }

    }


    if (menuToggle && navigation) {

        menuToggle.addEventListener(
            "click",
            function (event) {

                event.stopPropagation();


                const isOpen =
                    navigation.classList.contains(
                        "is-open"
                    );


                if (isOpen) {

                    closeMenu();

                } else {

                    /* Close Search */

                    const searchPanel =
                        document.querySelector(
                            ".search-panel"
                        );

                    const searchIcon =
                        document.querySelector(
                            ".search-icon"
                        );

                    const searchToggle =
                        document.querySelector(
                            ".search-toggle"
                        );


                    if (searchPanel) {

                        searchPanel.classList.remove(
                            "is-open"
                        );

                    }


                    if (searchIcon) {

                        searchIcon.textContent = "⌕";

                    }


                    if (searchToggle) {

                        searchToggle.setAttribute(
                            "aria-label",
                            "Open search"
                        );

                        searchToggle.setAttribute(
                            "aria-expanded",
                            "false"
                        );

                    }


                    navigation.classList.add(
                        "is-open"
                    );


                    if (menuIcon) {

                        menuIcon.textContent = "✕";

                    }


                    menuToggle.setAttribute(
                        "aria-label",
                        "Close menu"
                    );

                    menuToggle.setAttribute(
                        "aria-expanded",
                        "true"
                    );

                }

            }
        );


        navigation
            .querySelectorAll("a")
            .forEach(function (link) {

                link.addEventListener(
                    "click",
                    closeMenu
                );

            });

    }


    document.addEventListener(
        "click",
        function (event) {

            if (
                navigation &&
                menuToggle &&
                !navigation.contains(event.target) &&
                !menuToggle.contains(event.target)
            ) {

                closeMenu();

            }

        }
    );

})();